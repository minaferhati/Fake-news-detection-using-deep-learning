#!/usr/bin/env python
# coding: utf-8

# # Bi-LSTM model  on population data set 

# The first model would be only for the text column with a binary target Fake/Not Fake.
# This model is done by Andrii Shchur, 2020
# Here is its [article](https://towardsdatascience.com/fake-news-detector-with-deep-learning-approach-part-i-eda-757f5c052)

# ### <span style="background-color: #FFFF00">In this notebook, I have corrected the preprocessing of the data</span>

# ## Importing packages 

# In[ ]:


# Load libraries
import pandas as pd
import numpy as np
import os.path as op
import time
import matplotlib.pyplot as plt
import string
#Loading tensorflow and keras 
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import one_hot
from keras.utils import plot_model
from sklearn.preprocessing import OrdinalEncoder
#Loading nltk
import nltk
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
#Loading sklearn
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, f1_score, roc_auc_score
#Loading K-folds
from sklearn.model_selection import StratifiedKFold
#Loading the model 
import sys  
sys.path.insert(0, '../../models')
from PY.model4 import get_model


# ## Paths 

# In[ ]:


DATA_DIR = '../../../../Data'
CODE_DIR_H5='../../models/H5'
# Create a path for the saving location of the model
MODEL_DIR_H5 = CODE_DIR_H5 + '/model1_Kaggle.h5'


# ## Loading Data 

# In[ ]:


# Load train data
claims_input = pd.read_csv(op.join(DATA_DIR, 'weather/Claims_to_work_with/claims_DL_2.csv') )
claims_input


# In[130]:


train=claims_input.copy()


# In[131]:


# Find Na 
train.isnull().sum()


# In[132]:


# Define the function to remove the punctuation
def remove_punctuations(text):
    for punctuation in string.punctuation:
        text = text.replace(punctuation, '')
    return text
# Apply to the DF series
train['object'] = train['object'].apply(remove_punctuations)


# In[133]:


#Get the Depndent feature
X_train=train.drop('label',axis=1)
y_train=train['label']


# In[134]:


# set vocabulary size
vo_size=500
messages=X_train.copy()
messages.reset_index(inplace=True)


# In[135]:


len(messages), len(y_train)


# In[136]:


# one hot representation
onehot_rep = [one_hot(words, vo_size) for words in train.object]


# In[139]:


onehot_rep_value=[]
onehot_rep_value1=[]


# In[ ]:


for x in train.value:
    x1= x * 100
    x1=int(x1)
    onehot_rep_value1.append(x1)


# In[140]:


for x2 in  onehot_rep_value1:
    x3=((x2- min(train.value) )/ (max(train.value) - min(train.value)))
    onehot_rep_value.append(x3)


# In[141]:


onehot_rep_value


# In[142]:


flat_list = []
for sublist in onehot_rep:
    for item in sublist:
        flat_list.append(item)


# In[143]:


flat_list


# In[144]:


input_list = [[a,b] for a, b in zip(flat_list, onehot_rep_value)]
input_list


# In[145]:


# pad_sequences
sent_length = 2


# In[146]:


embedding_vector_feature = 10


# In[147]:


# final data for NN
X_final=np.array(input_list)
y_final=np.array(y_train)
X_final.shape,y_final.shape


# ## Training  the model 

# In[148]:


start=time.time()
# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
# define 10-fold cross validation test harness
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)
cvscores1 = []
cvscores2 = []
cvscores3 = []
cvscores4 = []
num_iter=0

for train, test in kfold.split(X_final, y_final):
    num_iter=num_iter+1
    model=get_model1(vo_size,embedding_vector_feature,sent_length)
    # Fit the model
    history=model.fit(X_final[train], y_final[train], epochs=10, batch_size=64,verbose=0)
    # evaluate the model
    scores = model.evaluate(X_final[test], y_final[test], verbose=0)
    print("------subset number", num_iter,"------")
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    cvscores1.append(scores[1] * 100)
    print("%s: %.2f%%" % (model.metrics_names[2], scores[2]*100))
    cvscores2.append(scores[2] * 100)
    print("%s: %.2f%%" % (model.metrics_names[3], scores[3]*100))
    cvscores3.append(scores[3] * 100)
    print("%s: %.2f%%" % (model.metrics_names[4], scores[4]*100))
    cvscores4.append(scores[4] * 100)
print("--------------------------------------------" )   
print("accuracy","%.2f%% (+/- %.2f%%)" % (np.mean(cvscores1), np.std(cvscores1)))
print("precision","%.2f%% (+/- %.2f%%)" % (np.mean(cvscores2), np.std(cvscores2)))
print("recall","%.2f%% (+/- %.2f%%)" % (np.mean(cvscores3), np.std(cvscores3)))
print("f1-mesure","%.2f%% (+/- %.2f%%)" % (np.mean(cvscores4), np.std(cvscores4)))
end=time.time()


# In[149]:


# Save the model
model.save(MODEL_DIR_H5)
model.summary()


# In[150]:


print('time of training' , end-start)


# ## Evaluation metrics

# In[151]:


# summarize history for accuracy
plt.plot(history.history['accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.show()


# In[152]:


# summarize history for loss
plt.plot(history.history['loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.show()


# In[153]:


# summarize history for f1-mesure
plt.plot(history.history['f1_mesure'])
plt.title('model F1-mesure')
plt.ylabel('F1-mesure')
plt.xlabel('epoch')
plt.show()


# In[154]:


# summarize history for precision
plt.plot(history.history['precision_mesure'])
plt.title('model precision')
plt.ylabel('precision')
plt.xlabel('epoch')
plt.show()


# In[155]:


# summarize history for recall
plt.plot(history.history['recall_mesure'])
plt.title('model recall')
plt.ylabel('recall')
plt.xlabel('epoch')
plt.show()


# In[ ]:




