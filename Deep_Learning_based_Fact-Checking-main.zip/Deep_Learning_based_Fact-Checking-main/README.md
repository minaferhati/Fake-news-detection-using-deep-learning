# Deep_Learning_based_Fact-Checking
Comparative analysis of Deep Learning-based fact-checking methods
