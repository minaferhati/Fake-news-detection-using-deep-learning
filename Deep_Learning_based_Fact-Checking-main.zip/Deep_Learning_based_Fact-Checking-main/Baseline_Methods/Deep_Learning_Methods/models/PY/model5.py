from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding
from tensorflow.keras.layers import LSTM,Input, Flatten
from tensorflow.keras.layers import Dense
import sys  
sys.path.insert(0, '../evaluation_mesures')
from evaluation_mesures import f1_mesure as f1, precision_mesure as precision, recall_mesure as recall
def get_model(vo_size,embedding_vector_feature,sent_length):
	model = None
	embedding_layer =Embedding(vo_size,embedding_vector_feature,input_length=sent_length)
	sequence_input = Input(shape=(sent_length,), dtype='int32')
	embedded_sequences = embedding_layer(sequence_input)
	l_lstm = LSTM(100, return_sequences=True)(embedded_sequences)
	f = Flatten()(l_lstm)
	preds = Dense(2, activation='softmax')(f)
	model = Model(sequence_input, preds)
    # Compile model
	model.compile(loss='sparse_categorical_crossentropy', optimizer='rmsprop', metrics=['accuracy',precision, recall,f1])
	return model