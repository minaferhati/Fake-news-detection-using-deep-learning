#!/usr/bin/env python
# coding: utf-8

# #  Latent Credible Analysis method on the weather data set 

# ## Introduction 
# 
# In this notebook, we will implement [*Latent Credible Analysis*](https://research.fb.com/publications/latent-credibility-analysis/) models. These are latent probablistic models that use hidden (latent) variables to represents the unknown data source reliabilities and underlying truth values. 
# 
# We implement only simpleLCA for now as extension to other models are relatively straight forward.

# 
# 
# # SimpleLCA
# 
# Here is the plate model of simpleLCA. 
# 
# ![simpleLCA](./gfx/simpleLCA.png)

# ## Importing packages 

# In[2]:


get_ipython().run_line_magic('load_ext', 'autoreload')
get_ipython().run_line_magic('autoreload', '2')


# In[3]:


import pandas as pd
import os.path as op
import numpy as np
import seaborn as sns
import pyro

import sys
sys.path.insert(0, '../')

from LCA.preprocessing import encoders
from LCA.judge import lca, utils
from LCA import evaluator
import time


# In[4]:


DATA_DIR = '../../../Data'


# In[5]:


truths = pd.read_csv(op.join(DATA_DIR, 'weather/Claims_to_work_with/truths_with_encoding_INT.csv'))
claims = pd.read_csv(op.join(DATA_DIR,'weather/Claims_to_work_with/claims_with_encoding_INT.csv'))


# In[6]:


truths.shape, claims.shape


# ## Data Preprocessing 

# We decide to model city population as discrete value. Moreover we consider the hidden truth value is only from the set of available assertions. Thus we need to label encode `value` of claims data frame.

# We need to label encode values of objects in order to feed them to our simpleLCA model

# In[7]:


#claims['value'] = claims['value'].apply(np.int64)


# In[8]:


claims_enc, le_dict = encoders.transform(claims)


# In[9]:


claims_enc


# ## Main program 

# In[10]:


import matplotlib.pyplot as plt
import numpy as np
import torch

import pyro
import pyro.infer
import pyro.optim
import pyro.distributions as dist

pyro.set_rng_seed(101)


# In[11]:


# svi = lca.bvi(lca.lca_model, lca.lca_guide, claims_enc, epochs=20, num_samples=1, learning_rate=1e-5)
svi = lca.bvi(lca.lca_model, lca.lca_guide, claims_enc, learning_rate=0.1, num_samples=1)


# In[12]:


losses = []


# In[13]:


losses.extend(lca.fit(svi, claims_enc, epochs=2))


# In[ ]:


start=time.time()
discovered_truths = lca.discover_truths(posteriors=pyro.get_param_store())


# We need to inverse transform the discovered truth value of each object into their original space.

# In[ ]:


discovered_truths['value'] = discovered_truths.apply(lambda x: le_dict[x['object_id']].inverse_transform([x['value']])[0], axis=1)
end=time.time()


# ## Calculate the accuracy 

# In[ ]:


accuracy =evaluator.accuracy(truths, discovered_truths)


# ## The final results 

# In[ ]:


print(end-start)
print(accuracy)


# In[ ]:




