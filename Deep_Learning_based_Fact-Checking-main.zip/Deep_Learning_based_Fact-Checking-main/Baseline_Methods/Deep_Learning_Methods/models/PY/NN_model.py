import os
import pandas as pd
import numpy as np
import os.path as op
from sklearn.model_selection import train_test_split
# KERAS LIBRARIES
from keras.layers import Dense
from keras.layers import Dropout
from keras.models import Sequential
from keras.optimizers import SGD
import time
#Loading K-folds
from sklearn.model_selection import StratifiedKFold
import sys  
sys.path.insert(0, '../evaluation_mesures')
from evaluation_mesures import f1_mesure as f1, precision_mesure as precision, recall_mesure as recall
def get_model(fhl_units, shl_units, thl_units,sources_num,random_seed1,learning_rate):
	model = Sequential([
        Dense(units=fhl_units, input_dim=sources_num, activation='relu'),  # input layer
        Dropout(0.2, noise_shape=None, seed=random_seed1),
        Dense(units=shl_units, activation='relu'),  # first hidden layer
        Dense(units=thl_units, activation='relu'),  # second hidden layer
        Dense(units=1, activation='sigmoid')    # output layer, 1 neuron,
	])
	model.compile(SGD(lr=learning_rate), loss="binary_crossentropy", metrics=['accuracy',precision, recall,f1])
	return model