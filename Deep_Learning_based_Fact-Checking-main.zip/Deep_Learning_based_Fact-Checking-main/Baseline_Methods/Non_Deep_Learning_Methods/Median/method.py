__author__ = 'JasonLee'
import csv
import numpy as np
import sys
import math
import time 

def getmedian(e2l):
    e2a = {}
    for example in e2l:
        mean = np.median(e2l[example])
        e2a[example] = mean

    return e2a

def gete2l(datafile):
    e2l = {}
    f = open(datafile, 'r')
    reader = csv.reader(f)
    next(reader)

    for line in reader:
        example, worker, label = line
        if example not in e2l:
            e2l[example] = []
        e2l[example].append(float(label))

    return e2l

def getMAE(datafile, truthfile, e2lpd):
    label_set = get_label_set(datafile) 
    # in case that e2lpd does not have data in the truthfile, then we randomly sample a label from label_set
    
    e2truth = {}
    f = open(truthfile, 'r')
    reader = csv.reader(f)
    next(reader)

    for line in reader:
        example, truth = line
        e2truth[example] = truth

    value = 0
    

    for e in e2truth:

        if e not in e2lpd:
            #randomly select a label from label_set
            truth = random.choice(label_set)
            value += abs( float(truth) - float(e2truth[e]) )
            continue

        if type(e2lpd[e]) == type({}):
            temp = 0
            for label in e2lpd[e]:
                if temp < e2lpd[e][label]:
                    temp = e2lpd[e][label]
        
            candidate = []

            for label in e2lpd[e]:
                if temp == e2lpd[e][label]:
                    candidate.append(label)

            truth = random.choice(candidate)

        else:
            truth = e2lpd[e]

        value += abs( float(truth) - float(e2truth[e]) )

    return value*1.0/len(e2truth)

def get_label_set(datafile):
    label_set=[]

    f = open(datafile, 'r')
    reader = csv.reader(f)
    next(reader)

    for line in reader:
        _, _, label = line

        if label not in label_set:
            label_set.append(label)

    return label_set

def getRMSE(datafile, truthfile, e2lpd):
    label_set = get_label_set(datafile) 
    # in case that e2lpd does not have data in the truthfile, then we randomly sample a label from label_set
    
    e2truth = {}
    f = open(truthfile, 'r')
    reader = csv.reader(f)
    next(reader)

    for line in reader:
        example, truth = line
        e2truth[example] = truth

    value = 0
    

    for e in e2truth:

        if e not in e2lpd:
            #randomly select a label from label_set
            truth = random.choice(label_set)
            value += ( float(truth) - float(e2truth[e]) )**2
            continue

        if type(e2lpd[e]) == type({}):
            temp = 0
            for label in e2lpd[e]:
                if temp < e2lpd[e][label]:
                    temp = e2lpd[e][label]
        
            candidate = []

            for label in e2lpd[e]:
                if temp == e2lpd[e][label]:
                    candidate.append(label)

            truth = random.choice(candidate)

        else:
            truth = e2lpd[e]

        value += ( float(truth) - float(e2truth[e]) )**2

    return math.sqrt( value*1.0/len(e2truth) )

if __name__ == "__main__":
    datafile = sys.argv[1]
    start=time.time()
    e2l = gete2l(datafile)
    e2a = getmedian(e2l)
    end = time.time()
    truthfile = sys.argv[2]
    MAE=getMAE(datafile, truthfile, e2a)
    RMSE=getRMSE(datafile, truthfile, e2a)
    
    
    print (e2a)
    print(end - start)
    print (MAE)
    print(RMSE)
    
