from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding 
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input,GlobalMaxPool1D,Dropout,concatenate
import sys  
sys.path.insert(0, '../evaluation_mesures')
from evaluation_mesures import f1_mesure as f1, precision_mesure as precision, recall_mesure as recall
def get_model(vo_size,embedding_vector_feature_title,embedding_vector_feature_text,input_title,input_text):
	emb_title = Embedding(vo_size,embedding_vector_feature_title)(input_title)
	lstm_title = LSTM(128, return_sequences=False)(emb_title)

	emb_text = Embedding(vo_size,embedding_vector_feature_text)(input_text)
	lstm_text = LSTM(128, return_sequences=True)(emb_text)
	max_pool_text = GlobalMaxPool1D()(lstm_text)
	dropout_1_text = Dropout(0.1)(max_pool_text)
	dense_1_text = Dense(50, activation='relu')(dropout_1_text)
	dropout_2_text = Dropout(0.1)(dense_1_text)

	out = concatenate([lstm_title,dropout_2_text],axis=-1)
	output=Dense(1, activation='sigmoid')(out)

	model = Model(inputs=[input_title, input_text], outputs=output)
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy',precision, recall,f1])
	return model