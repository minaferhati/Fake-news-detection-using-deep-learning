from tensorflow.keras.layers import LSTM
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Input,GlobalMaxPool1D,Dropout
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding
import sys  
sys.path.insert(0, '../evaluation_mesures')
from evaluation_mesures import f1_mesure as f1, precision_mesure as precision, recall_mesure as recall
def get_model(vo_size,embedding_vector_feature,sent_length):
	model = Sequential()
	model.add(Embedding(vo_size,embedding_vector_feature,input_length=sent_length))
	model.add(LSTM(100, return_sequences=True,name='lstm_layer'))
	model.add(GlobalMaxPool1D())
	model.add(Dropout(0.1))
	model.add(Dense(50, activation='relu'))
	model.add(Dropout(0.1))
	model.add(Dense(1,activation='sigmoid'))
    # Compile model
	model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy',precision, recall,f1])
	return model