#!/usr/bin/env python
# coding: utf-8

# #  Latent Credible Analysis method on the population data set 

# ## Introduction 
# 
# In this notebook, we will implement [*Latent Credible Analysis*](https://research.fb.com/publications/latent-credibility-analysis/) models. These are latent probablistic models that use hidden (latent) variables to represents the unknown data source reliabilities and underlying truth values. 
# 
# We implement only simpleLCA for now as extension to other models are relatively straight forward.

# 
# 
# ## SimpleLCA
# 
# Here is the plate model of simpleLCA. 
# 
# ![simpleLCA](./gfx/simpleLCA.png)

# ## Importing packages 

# In[1]:


get_ipython().run_line_magic('load_ext', 'autoreload')
get_ipython().run_line_magic('autoreload', '2')


# In[2]:


#!pip install http://download.pytorch.org/whl/cpu/torch-0.4.0-cp27-cp27mu-linux_x86_64.whl 
get_ipython().system('pip install pyro-ppl')


# In[3]:


get_ipython().system('pip install statsmodels ')


# In[4]:


import pandas as pd
import os.path as op
import numpy as np
import seaborn as sns
import pyro

import sys
sys.path.insert(0, '../')

from LCA.preprocessing import encoders
from LCA.judge import lca, utils
from LCA import evaluator
import time


# In[5]:


DATA_DIR = '../../../Data'


# In[6]:


truths = pd.read_csv(op.join(DATA_DIR, 'flights/Claims_to_work_with/truths_with_encoding.csv'))
claims = pd.read_csv(op.join(DATA_DIR,'flights/Claims_to_work_with/claims_with_encoding.csv'))


# In[7]:


truths.shape, claims.shape


# ## Data Preprocessing 

# We decide to model city population as discrete value. Moreover we consider the hidden truth value is only from the set of available assertions. Thus we need to label encode `value` of claims data frame.

# We need to label encode values of objects in order to feed them to our simpleLCA model

# In[9]:


claims_enc, le_dict = encoders.transform(claims)


# In[10]:


claims_enc


# ## Main program 

# In[11]:


import matplotlib.pyplot as plt
import numpy as np
import torch
import pyro
import pyro.infer
import pyro.optim
import pyro.distributions as dist
pyro.set_rng_seed(101)


# In[ ]:


# svi = lca.bvi(lca.lca_model, lca.lca_guide, claims_enc, epochs=20, num_samples=1, learning_rate=1e-5)
start=time.time()
svi = lca.bvi(lca.lca_model, lca.lca_guide, claims_enc, learning_rate=0.1, num_samples=1)
losses = []
losses.extend(lca.fit(svi, claims_enc, epochs=5))
discovered_truths = lca.discover_truths(posteriors=pyro.get_param_store())
#We need to inverse transform the discovered truth value of each object into their original space.
discovered_truths['value'] = discovered_truths.apply(lambda x: le_dict[x['object_id']].inverse_transform([x['value']])[0], axis=1)
end=time.time()


# ## Calculate the accuracy 

# In[ ]:


accuracy =evaluator.accuracy(truths, discovered_truths)


# ## The final results 

# In[ ]:


print(end-start)
print(accuracy)


# In[ ]:


#The result is bad. This is expected if we look at the plot of loss values during training. They did not converge! The following can be reasons:
#1. Since SVI estimate gradients at each training step by performing sampling of `guide()`. The default number of is 1. We may increase the estimation accuracy by increasing the number of training.
#2. Our `guide()` model is just not good enough or `model()'''

